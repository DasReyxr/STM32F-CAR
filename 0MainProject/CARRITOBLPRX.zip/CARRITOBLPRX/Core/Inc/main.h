/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RED_Pin GPIO_PIN_13
#define RED_GPIO_Port GPIOC
#define YELLOW_Pin GPIO_PIN_14
#define YELLOW_GPIO_Port GPIOC
#define GREEN_Pin GPIO_PIN_15
#define GREEN_GPIO_Port GPIOC
#define LUZ_Pin GPIO_PIN_0
#define LUZ_GPIO_Port GPIOD
#define STOP_Pin GPIO_PIN_1
#define STOP_GPIO_Port GPIOD
#define LeftFront_Pin GPIO_PIN_3
#define LeftFront_GPIO_Port GPIOA
#define LeftBack_Pin GPIO_PIN_4
#define LeftBack_GPIO_Port GPIOA
#define RightFront_Pin GPIO_PIN_5
#define RightFront_GPIO_Port GPIOA
#define RightBack_Pin GPIO_PIN_6
#define RightBack_GPIO_Port GPIOA
#define LED_DIR1_Pin GPIO_PIN_0
#define LED_DIR1_GPIO_Port GPIOB
#define LED_DIR2_Pin GPIO_PIN_1
#define LED_DIR2_GPIO_Port GPIOB
#define CSN_Pin GPIO_PIN_8
#define CSN_GPIO_Port GPIOA
#define IRQ_Pin GPIO_PIN_9
#define IRQ_GPIO_Port GPIOA
#define CE_Pin GPIO_PIN_10
#define CE_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
